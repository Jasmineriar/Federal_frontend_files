Step-1:

docker compose rm   
docker compose build
docker compose up 

Step-2:

docker pull rishabhjain2002/finalapp:v2
docker run -d -p 8000:3000 rishabhjain2002/finalapp:v2